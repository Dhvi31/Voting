import { useState, useEffect } from "react";
import axios from "axios";

export default function Elections() {
  const [elections, setElections] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/admin/elections").then(res => setElections(res.data));
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">All Elections</h2>
      <table className="border">
        <thead>
          <tr><th>Title</th><th>Start</th><th>End</th></tr>
        </thead>
        <tbody>
          {elections.map(e => (
            <tr key={e.id}>
              <td>{e.title}</td>
              <td>{e.start_date}</td>
              <td>{e.end_date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}