import { useState, useEffect } from "react";
import axios from "axios";

export default function Voters() {
  const [voters, setVoters] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/admin/voters").then(res => setVoters(res.data));
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Registered Voters</h2>
      <ul>
        {voters.map(v => (
          <li key={v.voter_id}>{v.name} ({v.email})</li>
        ))}
      </ul>
    </div>
  );
}