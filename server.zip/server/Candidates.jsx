import { useState, useEffect } from "react";
import axios from "axios";

export default function Candidates() {
  const [elections, setElections] = useState([]);
  const [selected, setSelected] = useState("");
  const [user, setUser] = useState("");
  const [manifesto, setManifesto] = useState("");
  const [candidates, setCandidates] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/admin/elections").then(res => setElections(res.data));
    axios.get("http://localhost:5000/api/admin/candidates").then(res => setCandidates(res.data));
  }, []);

  const handleAdd = async () => {
    await axios.post("http://localhost:5000/api/admin/candidates", { selected, user, manifesto });
    alert("Candidate Added!");
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Manage Candidates</h2>
      <select onChange={(e) => setSelected(e.target.value)} className="border p-2 mb-2">
        <option>Select Election</option>
        {elections.map((el) => <option key={el.id}>{el.title}</option>)}
      </select>
      <input placeholder="Candidate Name" onChange={(e) => setUser(e.target.value)} className="block border mb-2 p-2"/>
      <textarea placeholder="Manifesto" onChange={(e) => setManifesto(e.target.value)} className="block border mb-2 p-2"/>
      <button onClick={handleAdd} className="bg-green-600 text-white px-4 py-2 rounded">Add Candidate</button>

      <h3 className="text-lg mt-6 font-medium">Current Candidates</h3>
      <ul className="list-disc ml-6">
        {candidates.map(c => <li key={c.id}>{c.user} - {c.election}</li>)}
      </ul>
    </div>
  );
}