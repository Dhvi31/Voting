// ===============================
// server.js — VoteVibes Backend (Persistent Data + OTP Login)
// ===============================

import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import bodyParser from "body-parser";
import sgMail from "@sendgrid/mail";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// --- Configure SendGrid ---
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

// -------------------------------
// 🔹 ADMIN EMAILS (fixed list)
// -------------------------------
const ADMIN_EMAILS = [
  "iit2024104@iiita.ac.in",
  "iit2024028@iiita.ac.in",
  "iit2024031@iiita.ac.in",
  "iit2024042@iiita.ac.in",
  "iit2024089@iiita.ac.in",
  "iit2024091@iiita.ac.in"
];

// -------------------------------
// 🔹 Persistent Storage (data.json)
// -------------------------------
const DATA_FILE = "./data.json";

// Read file
function readData() {
  if (!fs.existsSync(DATA_FILE)) {
    const init = { voters: [], elections: [], candidates: [] };
    fs.writeFileSync(DATA_FILE, JSON.stringify(init, null, 2));
    return init;
  }
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}

// Write file
function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// In-memory OTP store
const otpStore = new Map();

// -------------------------------
// ✅ OTP LOGIN SYSTEM
// -------------------------------

// ✅ Send OTP
app.post("/send-otp", async (req, res) => {
  const { email } = req.body;
  if (!email)
    return res.status(400).json({ success: false, message: "Email required" });

  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  otpStore.set(email.toLowerCase(), otp);

  const msg = {
    to: email,
    from: process.env.ADMIN_EMAIL,
    subject: "Your OTP for VoteVibes Login",
    text: `Your OTP is ${otp}. It will expire in 2 minutes.`,
  };

  try {
    await sgMail.send(msg);
    console.log(`✅ OTP sent to ${email}: ${otp}`);
    res.status(200).json({ success: true, message: "OTP sent successfully!" });

    // expire OTP after 2 minutes
    setTimeout(() => otpStore.delete(email.toLowerCase()), 120000);
  } catch (error) {
    console.error("❌ SendGrid Error:", error);
    res.status(500).json({ success: false, message: "Failed to send OTP" });
  }
});

// ✅ Verify OTP
app.post("/verify-otp", (req, res) => {
  const { email, otp } = req.body;
  const normalizedEmail = email.toLowerCase();
  const storedOtp = otpStore.get(normalizedEmail);

  if (!storedOtp)
    return res.status(400).json({ success: false, message: "OTP expired or not found" });

  if (storedOtp === otp) {
    otpStore.delete(normalizedEmail);

    const data = readData();

    // check role (admin or voter)
    const isAdmin = ADMIN_EMAILS.includes(normalizedEmail);
    const name = email.split("@")[0].toUpperCase();

    // if voter not already present, add them
    const exists = data.voters.find(v => v.email === normalizedEmail);
    if (!exists) {
      data.voters.push({
        id: uuidv4(),
        name,
        email: normalizedEmail,
        role: isAdmin ? "admin" : "voter",
        createdAt: new Date().toISOString(),
      });
      writeData(data);
      console.log(`🧾 Added ${isAdmin ? "admin" : "voter"}: ${name} (${email})`);
    }

    return res.status(200).json({ success: true, message: "OTP verified successfully!" });
  } else {
    return res.status(400).json({ success: false, message: "Invalid OTP" });
  }
});

// -------------------------------
// ✅ ADMIN PANEL API (Persistent)
// -------------------------------

// ✅ Get Elections
app.get("/api/admin/elections", (req, res) => {
  const data = readData();
  res.json(data.elections);
});

// ✅ Create Election
app.post("/api/admin/elections", (req, res) => {
  const { title, desc, start, end } = req.body;
  if (!title) return res.status(400).json({ success: false, message: "Title required" });

  const data = readData();
  const newElection = {
    id: uuidv4(),
    title,
    description: desc || "",
    start_date: start || "",
    end_date: end || "",
    createdAt: new Date().toISOString(),
  };
  data.elections.push(newElection);
  writeData(data);

  console.log(`🗳️ New election created: ${title}`);
  res.json({ success: true, message: "Election Created", election: newElection });
});

// ✅ Get Candidates
app.get("/api/admin/candidates", (req, res) => {
  const data = readData();
  res.json(data.candidates);
});

// ✅ Add Candidate
app.post("/api/admin/candidates", (req, res) => {
  const { electionId, userEmail, manifesto } = req.body;
  if (!electionId || !userEmail)
    return res.status(400).json({ success: false, message: "Missing election or user" });

  const data = readData();
  const election = data.elections.find(e => e.id === electionId);
  if (!election)
    return res.status(404).json({ success: false, message: "Election not found" });

  const voter = data.voters.find(v => v.email === userEmail);
  if (!voter)
    return res.status(404).json({ success: false, message: "User not found in voters" });
  if (voter.role === "admin")
    return res.status(400).json({ success: false, message: "Admin cannot be candidate" });

  const alreadyExists = data.candidates.some(c => c.electionId === electionId && c.userEmail === userEmail);
  if (alreadyExists)
    return res.status(400).json({ success: false, message: "Candidate already added for this election" });

  const newCandidate = {
    id: uuidv4(),
    electionId,
    electionTitle: election.title,
    userEmail,
    userName: voter.name,
    manifesto: manifesto || "",
    createdAt: new Date().toISOString(),
  };
  data.candidates.push(newCandidate);
  writeData(data);

  console.log(`👤 Candidate Added: ${voter.name} for ${election.title}`);
  res.json({ success: true, message: "Candidate Added", candidate: newCandidate });
});

// ✅ Get Voters
app.get("/api/admin/voters", (req, res) => {
  const data = readData();
  res.json(data.voters);
});

// -------------------------------
// ✅ START SERVER
// -------------------------------
app.listen(5000, () => console.log("🚀 VoteVibes Server running on port 5000"));