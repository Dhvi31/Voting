import { useState } from "react";
import axios from "axios";

export default function CreateElection() {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");

  const handleSubmit = async () => {
    await axios.post("http://localhost:5000/api/admin/elections", { title, desc, start, end });
    alert("Election Created!");
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Create New Election</h2>
      <input placeholder="Title" onChange={(e) => setTitle(e.target.value)} className="block border mb-2 p-2"/>
      <textarea placeholder="Description" onChange={(e) => setDesc(e.target.value)} className="block border mb-2 p-2"/>
      <input type="datetime-local" onChange={(e) => setStart(e.target.value)} className="block border mb-2 p-2"/>
      <input type="datetime-local" onChange={(e) => setEnd(e.target.value)} className="block border mb-2 p-2"/>
      <button onClick={handleSubmit} className="bg-green-600 text-white px-4 py-2 rounded">Create Election</button>
    </div>
  );
}