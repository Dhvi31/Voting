import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <div style={{ width: "250px", background: "#f4f4f4", height: "100vh", padding: "20px" }}>
      <h2 style={{ fontWeight: "bold", fontSize: "20px", marginBottom: "20px" }}>Vote Vibes Admin</h2>
      <nav style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <Link to="/admin/elections">🗳 Elections</Link>
        <Link to="/admin/candidates">👤 Candidates</Link>
        <Link to="/admin/voters">📋 Voters</Link>
        <Link to="/admin/create-election">➕ Create Election</Link>
      </nav>
    </div>
  );
}