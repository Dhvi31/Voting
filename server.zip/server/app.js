import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Elections from "./pages/Elections";
import Candidates from "./pages/Candidates";
import Voters from "./pages/Voters";
import CreateElection from "./pages/CreateElection";

function App() {
  return (
    <Router>
      <div className="flex">
        <Sidebar />
        <div className="p-6 w-full">
          <Routes>
            <Route path="/admin/elections" element={<Elections />} />
            <Route path="/admin/candidates" element={<Candidates />} />
            <Route path="/admin/voters" element={<Voters />} />
            <Route path="/admin/create-election" element={<CreateElection />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;